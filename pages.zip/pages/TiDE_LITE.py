import os
import yaml
import streamlit as st
import streamlit_authenticator as stauth
from yaml import SafeLoader
from StreamlitUI import StreamlitUI
from streamlit_option_menu import option_menu
from Forget_Username import forget_user
from Forgot_Password import forget_password
from Register import register
import logging
placeholder = st.empty()

with placeholder:
    selected_option = option_menu("",
                                  ["Register", "Login", "Forgot User", "Forgot Password"],
                                  default_index=1,
                                  orientation="horizontal",
                                  icons=["person-plus", "house-door", "journal", "journal-plus"])

if selected_option == "Register":
    register()

elif selected_option == "Login":
    config_path = os.path.join(os.getcwd(), 'config')
    #st.write(os.getcwd())
    st.markdown("<style> ul {display: inline-block;} </style>", unsafe_allow_html=True)

    with open(os.path.join(config_path, "users.yaml")) as file:
        config = yaml.load(file, Loader=SafeLoader)
    try:
        authenticator = stauth.Authenticate(
                config['credentials'],
                config['cookie']['name'],
                config['cookie']['key'],
                config['cookie']['expiry_days'],
                config['preauthorized']
            )
        name, authentication_status, username = authenticator.login('Login', 'main')
        if authentication_status is False:
            st.error("Username/Password is incorrect")
        if authentication_status is None:
            st.warning("Please enter username password")
        if authentication_status:
            placeholder.empty()
            logging.info("User Logged In")
            st.markdown("<style> ul {display: none;} </style>", unsafe_allow_html=True)
            st.sidebar.write("#")
            st.sidebar.info("Welcome " + name)
            dir_path = name.replace(" ", "_")
            if os.path.exists(os.path.join(os.getcwd(), 'config', 'temp_folders',dir_path)) is False:
                os.mkdir(os.path.join(os.getcwd(), 'config', 'temp_folders',dir_path), 0o777)  #tempfiles

            StreamlitUI(dir_path)
            authenticator.logout("Logout", "sidebar")


    except Exception as e:
        st.error(e)

elif selected_option == "Forgot User":
    forget_user()

elif selected_option == "Forgot Password":
    forget_password()
